x=in;
y=out;
plot(x,'r');
hold on;
plot(y,'k')
hold on;
text(1,50,'y');
text(0.5,-5,'x');