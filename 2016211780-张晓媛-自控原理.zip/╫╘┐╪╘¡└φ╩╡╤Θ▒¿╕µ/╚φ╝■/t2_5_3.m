[num,den]=linmod('t2_5_1')
printsys(num,den,'s')
