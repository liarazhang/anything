import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class pan5 extends JFrame{
	public static JButton button, button1, button2 = null;
	public pan5() {
		URL url = Thread.currentThread().getContextClassLoader().getResource("6.png");
		URL url1 = Thread.currentThread().getContextClassLoader().getResource("6.png");
		URL url2 = Thread.currentThread().getContextClassLoader().getResource("6.png");
		button = new JButton(new ImageIcon(url));
		button1 = new JButton(new ImageIcon(url));
		button2 = new JButton(new ImageIcon(url));
		
	}

}
