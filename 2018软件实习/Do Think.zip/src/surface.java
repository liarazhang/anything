import java.awt.*;
import javax.swing.*;


public class surface {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JTabbedpane1 jp = new JTabbedpane1();
		
	}

}
