package Face;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
	 
import javax.swing.*;
import javax.swing.table.*;

public class JToolBar1 extends JFrame{
	 
	  //  private static final long serialVersionUID = 1L;
	    private JTable table = null;
	    //private DefaultTableModel model=null;
	    public static JScrollPane js=null ;
	    public JToolBar1(){
	        //model = new DefaultTableModel(3,10);
	    	Object[][] str = {
	    			{20180101, "����", "", ""},
	    	};
	    	String[] title = {"���ڱ��", "Ա������", "�����ܱ�","ɾ��"};
	        table = new JTable(str, title);
	        table.getColumnModel().getColumn(2).setCellEditor(new MyRender());//���ñ༭��
	        table.getColumnModel().getColumn(2).setCellRenderer(new MyRender() );
	        table.getColumnModel().getColumn(3).setCellEditor(new MyRender(1));//���ñ༭��
	        table.getColumnModel().getColumn(3).setCellRenderer(new MyRender(1) );
	        table.setRowHeight(35);
	        js = new JScrollPane(table);
	    }
	//��Ⱦ ��  �༭��
	   class MyRender extends AbstractCellEditor implements TableCellRenderer,ActionListener, TableCellEditor{
	 
	    //private static final long serialVersionUID = 1L;
	    private JButton button =null;
	    public MyRender(){
	        button = new JButton("����");
	        button.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		JFrame fra = new JFrame();
					fra.setTitle("���ؽ���");
					fra.setSize(400, 400);
					fra.setLocation(500, 200);
					fra.setVisible(true);
	        }
	        	
	        });
	    }
	    public MyRender(int i){
	        button = new JButton("ɾ��");
	        button.addActionListener(this);
	    }
	 
	@Override
	    public Object getCellEditorValue() {
	        // TODO Auto-generated method stub
	        return null;
	    }
	 
	    @Override
	    public Component getTableCellRendererComponent(JTable table, Object value,
	            boolean isSelected, boolean hasFocus, int row, int column) {
	        // TODO Auto-generated method stub
	        return button;
	    }
	 
	@Override
	    public void actionPerformed(ActionEvent e) {
	        // TODO Auto-generated method stub
	       // JOptionPane.showMessageDialog(null, "��Ⱦ��ѧ��", "��Ϣ", JOptionPane.OK_OPTION);
	         
	    }
	 
	@Override
	    public Component getTableCellEditorComponent(JTable table, Object value,
	            boolean isSelected, int row, int column) {
	        // TODO Auto-generated method stub
	        return button;
	    }
	     
	}
	
}
	


