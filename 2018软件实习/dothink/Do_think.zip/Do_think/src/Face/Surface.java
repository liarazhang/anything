package Face;
import javax.swing.*;

public class Surface {
	public static void main(String[] args) {
		JTabbedPane jp = new JTabbedPane();
		}
}
