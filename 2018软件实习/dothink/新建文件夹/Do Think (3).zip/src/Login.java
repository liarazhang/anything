import java.awt.GridLayout;
import java.awt.event.ActionEvent;  
import java.awt.event.ActionListener;
import java.awt.Font;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener{

	private JPanel pan1,pan2,pan3,pan4,pan5 = null;
	JLabel title,name,password = null;
	JTextField name_in = null;
	JPasswordField password_in = null;
	JRadioButton rb1,rb2 = null;
	JButton b1,b2 = null;

	String sql1 = "jdbc:odbc:Database";
	String sql2 = "select * from ������Աע���";
	String sql3 = "select * from ������Աע���";
	
    public static void main(String[] args) {  
    	
    	Login mUI = new Login();  
    }  

    public Login() {  
    	JFrame frame =new JFrame();
        pan1 = new JPanel();  
        title = new JLabel("��ӭ��½��ϵͳ");
		title.setFont(new Font("����",Font.BOLD, 20));
		pan1.add(title);
		
        pan2 = new JPanel();
        name = new JLabel("�û�����");
        name_in = new JTextField(15);
        pan2.add(name);
        pan2.add(name_in);
        
        pan3 = new JPanel();     
        password = new JLabel("��    �룺"); 
        password_in = new JPasswordField(15);
		password_in.setEchoChar('*');
		pan3.add(password);
		pan3.add(password_in);
 
        pan4 = new JPanel();
        rb1 = new JRadioButton("������Ա");  
        rb2 = new JRadioButton("������Ա"); 
        ButtonGroup bg = new ButtonGroup();  
        bg.add(rb1);  
        bg.add(rb2);
        pan4.add(rb1);
        pan4.add(rb2);
        
        pan5 = new JPanel();
        b1 = new JButton("��¼");  
        b2 = new JButton("����"); 
        pan5.add(b1);
        pan5.add(b2);
        b2.addActionListener(this);  
        b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				JTabbedpane1 jp = new JTabbedpane1();
				
			}
			});  
         
        frame.add(pan1);  
        frame.add(pan2);  
        frame.add(pan3);  
        frame.add(pan4);  
        frame.add(pan5);

        frame.setLayout(new GridLayout(5,1));   
        frame.setTitle("��½Dothink���۹���ϵͳ");          
        frame.setSize(400,300);         
        frame.setLocation(400, 200);           
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);  
        frame.setResizable(false);  
    }  

    //����
    public void clear(){  
    	name_in.setText("");  
    	password_in.setText(""); 
    }
    
    //button�¼��ж�
    public void actionPerformed(ActionEvent e) {
//    	loop:
    		//if(e.getActionCommand() == "��¼"){
//    		if(rb1.isSelected()){  
//    			Access access = new Access();
//    			access.init(sql1);	//��ʼ�������������ӣ�
//    			try{
//    				access.query(sql3);	
//    				while(access.rs.next()){
//    					if(access.rs.getString(4).equals(name_in.getText().trim())&&access.rs.getString(5).equals(password_in.getText().trim())){
//    						//JOptionPane.showMessageDialog(pan1, "pass");
//    						JTabbedPane jp = new JTabbedPane();
//    						break loop;
//    					}
//    				}
//    			}
//    			catch(Exception ex){
//    				System.out.println("Database");
//    			}
//    			JOptionPane.showMessageDialog(pan1, "�û������������");
//    			name_in.setText("");
//    			password_in.setText("");
//    		}
//    		else if(rb2.isSelected()){  
//    			Access access = new Access();
//    			access.init(sql1);
//    			try{
//    				access.query(sql2);
//    				while(access.rs.next()){
//    					if(access.rs.getString(4).equals(name_in.getText().trim())&&access.rs.getString(5).equals(password_in.getText().trim())){
//    						//JOptionPane.showMessageDialog(pan1, "pass");
//    						JTabbedPane jp = new JTabbedPane();
//    						break loop;
//    					}
//    				}
//    			}
//    			catch(Exception ex){
//    				System.out.println("Database");
//    			}
//    			JOptionPane.showMessageDialog(pan1, "�û������������");
//    			name_in.setText("");
//    			password_in.setText("");
//           	}
//        }else 
        	if(e.getActionCommand() == "����"){  
                 clear();  
        	} 
    //	} 
    }  
}